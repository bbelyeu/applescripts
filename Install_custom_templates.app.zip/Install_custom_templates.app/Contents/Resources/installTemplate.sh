#! /bin/bash

/bin/mkdir -p ~/Library/Application\ Support/Final\ Cut\ Studio/Motion/Templates/
/bin/cp -Rf /Volumes/macaccess/ToddFraser/Applications\ Support/Final\ Cut\ Studio/Motion/Templates/NewsOK\ Templates ~/Library/Application\ Support/Final\ Cut\ Studio/Motion/Templates/

